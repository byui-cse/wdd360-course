import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/integration",
  use: {
    baseURL: "http://localhost:4333/src/pages/"
  },
  webServer: {
    command: "pnpm exec vite --host 0.0.0.0 --port 4333 --strictPort",
    url: "http://localhost:4333/src/pages/index.html",
    reuseExistingServer: true,
    timeout: 120000
  }
});
